using System;
using System.Collections;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using UnityEngine;

namespace FPE_Legacy.Content
{
    // Resolves the MelonLoader utility from the installed distribution. No copy of its implementation.
    internal sealed class FunBundleBackend
    {
        private readonly object _bundle;
        private FunBundleBackend(object bundle) { _bundle = bundle ?? throw new InvalidOperationException("AssetBundle load returned null."); }
        internal static async Task<FunBundleBackend> Open(string path)
        {
            Type type = AppDomain.CurrentDomain.GetAssemblies().Select(a => a.GetType("UnityEngine.Il2CppAssetBundleManager", false)).FirstOrDefault(t => t != null);
            if (type == null)
            {
                try { type = Assembly.Load("UnityEngine.Il2CppAssetBundleManager").GetType("UnityEngine.Il2CppAssetBundleManager", true); }
                catch (Exception e) { throw new InvalidOperationException("MelonLoader Il2CppAssetBundleManager utility is unavailable. Reference/install the utility shipped with MelonLoader 0.7.2.", e); }
            }
            var asyncMethod = type.GetMethods().FirstOrDefault(m => m.Name == "LoadFromFileAsync" && m.GetParameters().Length == 3);
            if (asyncMethod != null)
            {
                var request = asyncMethod.Invoke(null, new object[] { path, 0u, 0UL });
                if (request == null) throw new InvalidOperationException("LoadFromFileAsync returned null: " + path);
                await FunMainThread.Until(() => Convert.ToBoolean(Property(request, "isDone")));
                return new FunBundleBackend(Property(request, "assetBundle"));
            }
            var method = type.GetMethod("LoadFromFile", new[] { typeof(string) }) ?? throw new MissingMethodException("Il2CppAssetBundleManager.LoadFromFile");
            return new FunBundleBackend(method.Invoke(null, new object[] { path }));
        }
        internal string[] Names()
        {
            var result = _bundle.GetType().GetMethod("GetAllAssetNames", Type.EmptyTypes)?.Invoke(_bundle, null);
            if (result is string[] names) return names;
            if (result is IEnumerable enumerable) return enumerable.Cast<object>().Select(x => x.ToString()).ToArray();
            throw new MissingMethodException("Il2CppAssetBundle.GetAllAssetNames");
        }
        internal async Task<UnityEngine.Object> Load(string path, Type type)
        {
            var method = _bundle.GetType().GetMethods().FirstOrDefault(m => m.Name == "LoadAssetAsync" && m.IsGenericMethodDefinition && m.GetParameters().Length == 1);
            if (method != null)
            {
                var request = method.MakeGenericMethod(type).Invoke(_bundle, new object[] { path });
                if (request == null) throw new InvalidOperationException("Null asset request: " + path);
                await FunMainThread.Until(() => Convert.ToBoolean(Property(request, "isDone")));
                return Property(request, "asset") as UnityEngine.Object ?? throw new InvalidOperationException("Asset not found: " + path);
            }
            method = _bundle.GetType().GetMethods().FirstOrDefault(m => m.Name == "LoadAsset" && m.IsGenericMethodDefinition && m.GetParameters().Length == 1)
                ?? throw new MissingMethodException("Il2CppAssetBundle.LoadAsset<T>");
            return method.MakeGenericMethod(type).Invoke(_bundle, new object[] { path }) as UnityEngine.Object
                ?? throw new InvalidOperationException("Asset not found: " + path);
        }
        internal void Unload(bool destroyAssets) => _bundle.GetType().GetMethod("Unload", new[] { typeof(bool) }).Invoke(_bundle, new object[] { destroyAssets });
        private static object Property(object value, string name) => value.GetType().GetProperty(name)?.GetValue(value)
            ?? throw new MissingMemberException(value.GetType().FullName, name);
    }
    internal static class FunMainThread
    {
        private sealed class Waiter { internal Func<bool> Poll; internal TaskCompletionSource<bool> Completion = new(); }
        private static readonly List<Waiter> Waiters = new();
        private static int _thread;
        internal static void Initialize() { _thread = Thread.CurrentThread.ManagedThreadId; }
        internal static void Require()
        {
            if (_thread == 0 || Thread.CurrentThread.ManagedThreadId != _thread)
                throw new InvalidOperationException("FunContent/FunNetwork must be called on Unity's main thread. Do not use Task.Run or ConfigureAwait(false).");
        }
        internal static Task Until(Func<bool> poll)
        {
            Require();
            if (poll()) return Task.CompletedTask;
            var waiter = new Waiter { Poll = poll }; Waiters.Add(waiter); return waiter.Completion.Task;
        }
        internal static Task NextFrame()
        {
            var waiter = new Waiter { Poll = () => true }; Waiters.Add(waiter); return waiter.Completion.Task;
        }
        internal static void Tick()
        {
            foreach (var waiter in Waiters.ToArray())
            {
                try { if (!waiter.Poll()) continue; Waiters.Remove(waiter); waiter.Completion.TrySetResult(true); }
                catch (Exception e) { Waiters.Remove(waiter); waiter.Completion.TrySetException(e); }
            }
        }
    }
}
