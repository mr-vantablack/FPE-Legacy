using FPE_Legacy.Rpc;
using HarmonyLib;
using Il2Cpp;
using Il2CppFishNet.Connection;
using Il2CppFishNet.Object;
using Il2CppFishNet.Serializing;
using Il2CppFishNet.Transporting;
using Il2CppInterop.Runtime;
using MelonLoader;
using UnityEngine;
using UnityEngine.UI;

namespace FPE_Legacy.Patches
{
	[HarmonyPatch(typeof(PlayerDamage), "Awake")]
	public static class PlayerDamageAwake
	{
		[HarmonyPostfix]
		private static void Postfix(PlayerDamage __instance)
		{
			if (__instance.gameObject.GetComponent<Test>() == null)
				__instance.gameObject.AddComponent<Test>();
		}
	}
    [HarmonyPatch(typeof(Volume), "Awake")]
	public static class SandboxConsolePatch
	{
        [HarmonyPostfix]
        private static void Postfix(Volume __instance)
		{
			var cat = new Volume.catagory()
			{
				catagoryName = "Props",
				hostOnly = false,
				isPlayAs = false,
				isMusic = false,
				isWeapon = false,
				tagName = "props",
				options = new Il2CppSystem.Collections.Generic.List<Volume.option>()
			};

            __instance.PDKPIOHFCCK.Add(cat);

			var opt = new Volume.option()
			{
				image = null,
				optionName = "",
				resourcePath = ""
			};
			cat.options.Add(opt);
		}
    }
	[HarmonyLib.HarmonyPatch(typeof(Volume), "SendOption")]
	public static class VolumeSendOption
	{
		private static bool Prefix(Volume __instance, ref int theCatagory, ref int theOption) 
		{
			return true;
		}
	}

        [HarmonyPatch(typeof(Volume), "Awake")]
	public static class SandboxConsoleScroll
	{
		[HarmonyPostfix]
		private static void Postfix(Volume __instance)
		{
			string[] viewportNames =
			{
				"Canvas/Console/Catagories_UI",
				"Canvas/Console/Options_UI"
			};

			string[] contentNames =
			{
				"Catagories_Root",
				"Options_Root"
			};

			for (int i = 0; i < 2; i++)
			{
				Transform viewportTransform = __instance.transform.Find(viewportNames[i]);

				RectTransform viewport = viewportTransform.GetComponent<RectTransform>();
				Transform contentTransform = viewportTransform.Find(contentNames[i]);

				RectTransform content = contentTransform.GetComponent<RectTransform>();

				ScrollRect scroll = viewport.GetComponent<ScrollRect>();

				if (scroll == null) scroll = viewport.gameObject.AddComponent<ScrollRect>();

				RectMask2D mask = viewport.GetComponent<RectMask2D>();

				if (mask == null) mask = viewport.gameObject.AddComponent<RectMask2D>();

				Graphic graphic = viewport.GetComponent<Graphic>();

				if (graphic == null)
				{
					Image image = viewport.gameObject.AddComponent<Image>();
					image.color = new Color(0f, 0f, 0f, 0.001f);
					image.raycastTarget = true;
				}
				else
				{
					graphic.raycastTarget = true;
				}

				Canvas.ForceUpdateCanvases();

				Vector3[] corners = new Vector3[4];

				float highest = float.MinValue;
				float lowest = float.MaxValue;
				bool found = false;

				for (int c = 0; c < content.childCount; c++)
				{
					RectTransform child = content.GetChild(c) as RectTransform;

					if (child == null || !child.gameObject.activeSelf)
						continue;

					child.GetWorldCorners(corners);

					for (int p = 0; p < 4; p++)
					{
						Vector3 local = content.InverseTransformPoint(corners[p]);

						highest = Mathf.Max(highest, local.y);
						lowest = Mathf.Min(lowest, local.y);
					}

					found = true;
				}

				float requiredHeight = viewport.rect.height;

				if (found)
				{
					requiredHeight = Mathf.Max(viewport.rect.height, highest - lowest + 20f);
				}

				float oldHeight = content.rect.height;
				Vector2 oldPivot = content.pivot;
				Vector2 oldAnchoredPosition = content.anchoredPosition;

				float oldTop = oldAnchoredPosition.y + oldHeight * (1f - oldPivot.y);

				content.anchorMin = new Vector2(content.anchorMin.x, 1f);
				content.anchorMax = new Vector2(content.anchorMax.x, 1f);

                content.pivot = new Vector2(content.pivot.x, 1f);

				content.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, requiredHeight);

				Vector2 newPosition = content.anchoredPosition;
				newPosition.y = oldTop;
				content.anchoredPosition = newPosition;

				scroll.content = content;
				scroll.viewport = viewport;
				scroll.horizontal = false;
				scroll.vertical = true;
				scroll.movementType = ScrollRect.MovementType.Clamped;
				scroll.inertia = true;
				scroll.decelerationRate = 0.135f;
				scroll.scrollSensitivity = 60f;
				scroll.horizontalScrollbar = null;
				scroll.verticalScrollbar = null;

				Canvas.ForceUpdateCanvases();

				scroll.verticalNormalizedPosition = 1f;
			}
			__instance.transform.Find("Canvas/Console/Options_UI").GetComponent<RectTransform>().anchorMax = new Vector2(1, 0.91f); //fix
        }
	}

	[HarmonyPatch]
	public static class ReadServerRpcPatch
	{
		private static System.Reflection.MethodBase TargetMethod()
		{
			System.Reflection.MethodInfo method = AccessTools.Method(typeof(NetworkBehaviour), "ReadServerRpc", new System.Type[] { typeof(int), typeof(bool), typeof(uint), typeof(PooledReader), typeof(NetworkConnection), typeof(Channel) });

			if (method == null)
				MelonLogger.Error("[FunRPC] FishNet ReadServerRpc not found!");
			else
				MelonLogger.Msg("[FunRPC] Patched FishNet ReadServerRpc: " + method);

			return method;
		}

		private static bool Prefix(NetworkBehaviour __instance, int readerPositionAfterDebug, bool fromRpcLink, uint hash, PooledReader reader, NetworkConnection sendingClient, Channel channel)
		{
			bool consumed = FunRPCRuntime.TryConsumeIncoming(FunRPCKind.Server, __instance, fromRpcLink, hash, reader, sendingClient, channel);

			return !consumed;
		}
	}

	[HarmonyPatch]
	public static class ReadObserversRpcPatch
	{
		private static System.Reflection.MethodBase TargetMethod()
		{
			System.Reflection.MethodInfo method = AccessTools.Method(typeof(NetworkBehaviour), "ReadObserversRpc", new System.Type[] { typeof(int), typeof(bool), typeof(uint), typeof(PooledReader), typeof(Channel) });

			if (method == null)
				MelonLogger.Error("[FunRPC] FishNet ReadObserversRpc not found!");
			else
				MelonLogger.Msg("[FunRPC] Patched FishNet ReadObserversRpc: " + method);

			return method;
		}

		private static bool Prefix(NetworkBehaviour __instance, int readerPositionAfterDebug, bool fromRpcLink, uint hash, PooledReader reader, Channel channel)
		{
			bool consumed = FunRPCRuntime.TryConsumeIncoming(FunRPCKind.Observers, __instance, fromRpcLink, hash, reader, null, channel);

			return !consumed;
		}
	}

	[HarmonyPatch]
	public static class ReadTargetRpcPatch
	{
		private static System.Reflection.MethodBase TargetMethod()
		{
			System.Reflection.MethodInfo method = AccessTools.Method(typeof(NetworkBehaviour), "ReadTargetRpc", new System.Type[] { typeof(int), typeof(bool), typeof(uint), typeof(PooledReader), typeof(Channel) });

			if (method == null)
				MelonLogger.Error("[FunRPC] FishNet ReadTargetRpc not found!");
			else
				MelonLogger.Msg("[FunRPC] Patched FishNet ReadTargetRpc: " + method);

			return method;
		}

		private static bool Prefix(NetworkBehaviour __instance, int readerPositionAfterDebug, bool fromRpcLink, uint hash, PooledReader reader, Channel channel)
		{
			bool consumed = FunRPCRuntime.TryConsumeIncoming(FunRPCKind.Target, __instance, fromRpcLink, hash, reader, null, channel);

			return !consumed;
		}
	}
}
