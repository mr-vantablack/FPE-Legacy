using FPE_Legacy.Rpc;
using Il2Cpp;
using MelonLoader;
using UnityEngine;

[assembly: MelonInfo(typeof(FPE_Legacy.Core), "FPE Legacy", "1.0.0", "mr_vantablack", null)]
[assembly: MelonGame(null, null)]

namespace FPE_Legacy
{
    public class Core : MelonMod
    {
        public override void OnInitializeMelon()
        {
            LoggerInstance.Msg("Initialized.");

            RpcRuntime.Initialize();
            RpcAttributeRuntime.Initialize(typeof(Core).Assembly);

            //GameObject go = new GameObject("TestRpcController");
            //UnityEngine.Object.DontDestroyOnLoad(go);
           // go.AddComponent<Test>();

            LoggerInstance.Msg("[FunRPC] Numpad6 = attributed client -> server");
            LoggerInstance.Msg("[FunRPC] Numpad7 = attributed host -> observers");
            LoggerInstance.Msg("[FunRPC] Numpad8 = print NetworkBehaviours + connections");
            LoggerInstance.Msg("[FunRPC] Numpad9 = attributed host -> one client (TargetRpc)");
        }
    }
}
