using FPE_Legacy.Rpc;
using Il2CppFishNet.Connection;
using MelonLoader;
using System;
using UnityEngine;

namespace FPE_Legacy
{
    [RegisterTypeInIl2Cpp]
    public class Test : MonoBehaviour
    {
        public Test(IntPtr ptr) : base(ptr) { }

        public void Update()
        {
            try
            {
                // CLIENT -> SERVER.
                // This is now just a normal C# call. Harmony turns it into a network RPC.
                if (!RpcRuntime.IsLocalOwner(this)) return;
                if (Input.GetKeyDown(KeyCode.Keypad6))
                {
                    DemoServerRpc("Hello from CLIENT!", 123, 45.5f, true, new Vector3(1.25f, 2.5f, 3.75f));
                }

                // SERVER -> ALL OBSERVERS.
                if (Input.GetKeyDown(KeyCode.Keypad7))
                {
                    DemoObserversRpc("Hello from HOST!", 777, new Vector2(12f, 34f), Color.cyan);
                }

                if (Input.GetKeyDown(KeyCode.Keypad8))
                {
                    RpcRuntime.PrintNetworkBehaviours();
                }

                // SERVER -> ONE REMOTE CLIENT.
                if (Input.GetKeyDown(KeyCode.Keypad9))
                {
                    NetworkConnection target = RpcRuntime.GetFirstRemoteServerConnection();
                    if (target == null)
                    {
                        MelonLogger.Warning("[FunRPC] No remote client found for TargetRpc.");
                    }
                    else
                    {
                        // The first argument of a [ModTargetRpc] is always int clientId.
                        DemoTargetRpc(target.ClientId, "This message is ONLY for you", Time.time, new Vector3(9f, 8f, 7f));
                    }
                }
            }
            catch (Exception e)
            {
                MelonLogger.Error("[FunRPC] Update exception:\n" + e);
            }
        }

        // --------------------------------------------------------------------
        // CLIENT -> SERVER
        // --------------------------------------------------------------------

        [ModServerRpc]
        private void DemoServerRpc(string text, int number, float value, bool flag, Vector3 position)
        {
            int senderClientId = RpcAttributeRuntime.CurrentContext == null
                ? -1
                : RpcAttributeRuntime.CurrentContext.SenderClientId;

            MelonLogger.Msg($"[FunRPC] SERVER RPC EXECUTED. " + $"sender={senderClientId}, text='{text}', int={number}, " + $"float={value}, bool={flag}, pos={position}");
        }

        // --------------------------------------------------------------------
        // SERVER -> OBSERVERS
        // --------------------------------------------------------------------

        [ModObserversRpc(ExcludeServer = true)]
        private void DemoObserversRpc(string text, int number, Vector2 position, Color color)
        {
            MelonLogger.Msg($"[FunRPC] OBSERVERS RPC EXECUTED. " + $"text='{text}', int={number}, vec2={position}, color={color}");
        }

        // --------------------------------------------------------------------
        // SERVER -> ONE CLIENT
        // --------------------------------------------------------------------

        [ModTargetRpc]
        private void DemoTargetRpc(int clientId, string text, float serverTime, Vector3 position)
        {
            MelonLogger.Msg($"[FunRPC] TARGET RPC EXECUTED. " + $"targetClientId={clientId}, text='{text}', " + $"serverTime={serverTime}, pos={position}");
        }
    }
}
