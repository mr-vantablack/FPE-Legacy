using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using MelonLoader;
using MelonLoader.Utils;

namespace FPE_Legacy.SpawnUI
{
    internal sealed class FunSpawnSettings
    {
        internal readonly HashSet<string> Favorites = new(StringComparer.Ordinal);
        private string FilePath => Path.Combine(MelonEnvironment.GameRootDirectory,
            "UserData", "FunPlusEssentials", "spawn-favourites.json");

        internal void Load()
        {
            try
            {
                if (!File.Exists(FilePath)) return;
                var ids = JsonSerializer.Deserialize<List<string>>(File.ReadAllText(FilePath));
                if (ids == null) return;
                foreach (string id in ids)
                    if (!string.IsNullOrWhiteSpace(id)) Favorites.Add(id);
            }
            catch (Exception e) { MelonLogger.Warning("[SpawnUI] Cannot read favourites: " + e.Message); }
        }

        internal void Toggle(string id)
        {
            if (!Favorites.Remove(id)) Favorites.Add(id);
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(FilePath));
                string temporary = FilePath + ".tmp";
                File.WriteAllText(temporary, JsonSerializer.Serialize(Favorites));
                File.Move(temporary, FilePath, true);
            }
            catch (Exception e) { MelonLogger.Warning("[SpawnUI] Cannot save favourites: " + e.Message); }
        }
    }
}
