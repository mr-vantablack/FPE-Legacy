using System;
using System.Collections.Generic;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace FPE_Legacy.SpawnUI
{
    internal sealed class FunUiBuilder : IDisposable
    {
        internal static readonly Color TextColor = new(.91f, .94f, 1f, 1f);
        internal static readonly Color Muted = new(.55f, .62f, .74f, 1f);
        internal static readonly Color Surface = new(.09f, .12f, .18f, 1f);
        internal static readonly Color Accent = new(.21f, .73f, .58f, 1f);
        private readonly List<object> _delegates = new();
        private readonly List<Button> _buttons = new();
        private readonly List<InputField> _inputs = new();
        private Font _font;
        private bool _ownsFont;

        internal FunUiBuilder()
        {
            try { _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); }
            catch { /* The Windows OS font is the fallback for stripped built-in fonts. */ }
            if (_font == null)
            {
                _font = Font.CreateDynamicFontFromOSFont("Arial", 18);
                _ownsFont = true;
                if (_font != null) _font.hideFlags |= HideFlags.DontUnloadUnusedAsset;
            }
            if (_font == null) throw new InvalidOperationException("No font available for SpawnUI.");
        }

        internal static RectTransform Rect(string name, Transform parent)
        {
            var types = new Il2CppReferenceArray<Il2CppSystem.Type>(new[] { Il2CppType.Of<RectTransform>() });
            var go = new GameObject(name, types);
            var rect = go.GetComponent<RectTransform>();
            if (parent != null) rect.SetParent(parent, false);
            rect.localScale = Vector3.one;
            return rect;
        }

        internal static void Place(RectTransform rect, float x, float y, float width, float height)
        {
            rect.anchorMin = rect.anchorMax = new Vector2(0, 1);
            rect.pivot = new Vector2(0, 1);
            rect.anchoredPosition = new Vector2(x, -y);
            rect.sizeDelta = new Vector2(width, height);
        }

        internal static void Stretch(RectTransform rect)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = rect.offsetMax = Vector2.zero;
        }

        internal static Image Background(RectTransform rect, Color color, bool raycast = true)
        {
            var image = rect.gameObject.AddComponent<Image>();
            image.color = color;
            image.raycastTarget = raycast;
            return image;
        }

        internal Text Label(Transform parent, string name, string value,
            float x, float y, float width, float height, int size = 18, Color? color = null)
        {
            var rect = Rect(name, parent);
            Place(rect, x, y, width, height);
            var text = rect.gameObject.AddComponent<Text>();
            text.font = _font;
            text.fontSize = size;
            text.color = color ?? TextColor;
            text.alignment = TextAnchor.MiddleLeft;
            text.supportRichText = false;
            text.raycastTarget = false;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            text.text = value;
            return text;
        }

        internal Button Button(Transform parent, string title, float x, float y, float width,
            float height, Action action, out Text caption)
        {
            var rect = Rect("Button", parent);
            Place(rect, x, y, width, height);
            var image = Background(rect, Surface);
            var button = rect.gameObject.AddComponent<Button>();
            button.targetGraphic = image;
            var colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(.80f, .95f, 1f, 1f);
            colors.pressedColor = new Color(.55f, .85f, .75f, 1f);
            colors.disabledColor = new Color(.4f, .4f, .4f, .7f);
            button.colors = colors;
            var navigation = button.navigation;
            navigation.mode = Navigation.Mode.None;
            button.navigation = navigation;
            caption = Label(rect, "Label", title, 8, 0, width - 16, height, 17);
            caption.alignment = TextAnchor.MiddleCenter;
            Action guarded = () => FunSpawnConsole.Guard(action);
            var listener = DelegateSupport.ConvertDelegate<UnityAction>(guarded);
            _delegates.Add(guarded);
            _delegates.Add(listener);
            button.onClick.AddListener(listener);
            _buttons.Add(button);
            return button;
        }

        internal InputField Search(Transform parent, float x, float y, float width, Action<string> changed)
        {
            var rect = Rect("Search", parent);
            Place(rect, x, y, width, 42);
            var image = Background(rect, Surface);
            var text = Label(rect, "Text", "", 14, 0, width - 28, 42);
            text.horizontalOverflow = HorizontalWrapMode.Overflow;
            var placeholder = Label(rect, "Placeholder", "Поиск по названию, ID или пакету…", 14, 0, width - 28, 42, 17, Muted);
            var input = rect.gameObject.AddComponent<InputField>();
            input.targetGraphic = image;
            input.textComponent = text;
            input.placeholder = placeholder;
            input.lineType = InputField.LineType.SingleLine;
            input.characterLimit = 100;
            input.customCaretColor = true;
            input.caretColor = TextColor;
            Action<string> guarded = value => FunSpawnConsole.Guard(() => changed(value));
            var listener = DelegateSupport.ConvertDelegate<UnityAction<string>>(guarded);
            _delegates.Add(guarded);
            _delegates.Add(listener);
            input.onValueChanged.AddListener(listener);
            _inputs.Add(input);
            return input;
        }

        public void Dispose()
        {
            foreach (var b in _buttons) if (b != null) b.onClick.RemoveAllListeners();
            foreach (var i in _inputs) if (i != null) i.onValueChanged.RemoveAllListeners();
            _buttons.Clear(); _inputs.Clear(); _delegates.Clear();
            if (_ownsFont && _font != null) Object.Destroy(_font);
            _font = null;
        }
    }
}
