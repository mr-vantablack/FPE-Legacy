using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FPE_Legacy.Content;
using FPE_Legacy.Networking;
using MelonLoader;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace FPE_Legacy.SpawnUI
{
    // Called by Core; no injected MonoBehaviour or UI AssetBundle is required.
    public static class FunSpawnConsole
    {
        public static KeyCode ToggleKey = KeyCode.F4;
        public static bool IsOpen { get; private set; }
        public static bool CloseAfterSpawn = false;
        public static Func<Camera> CameraProvider = () => Camera.main;

        // Optional game-specific bridge. Return ONLY local movement/look/fire scripts.
        // Do not return Camera, player GameObject, NetworkBehaviour, or the networking driver.
        public static Func<IEnumerable<Behaviour>> GameplayBehavioursProvider;
        public static event Action<bool> OpenChanged;

        private const int PageSize = 8;
        private sealed class Card
        {
            internal GameObject Root;
            internal Image Background;
            internal Text Title, Id, Kind, Star;
            internal string AssetId;
        }
        private static readonly FunSpawnSettings Settings = new();
        private static readonly List<Card> Cards = new();
        private static readonly List<Behaviour> DisabledGameplay = new();
        private static readonly List<EventSystem> DisabledEvents = new();
        private static List<FunSpawnEntry> _catalogue = new();
        private static List<FunSpawnEntry> _filtered = new();
        private static List<string> _packages = new();
        private static GameObject _root, _eventRoot, _menuMarker;
        private static EventSystem _ownEvents, _previousEvents;
        private static FunUiBuilder _ui;
        private static InputField _search;
        private static Text _packageCaption, _favoriteCaption, _pageCaption, _status, _networkStatus;
        private static Text _detailTitle, _detailText, _distanceCaption, _favoriteDetail, _empty;
        private static Button _spawnButton, _previousPage, _nextPage, _favoriteButton;
        private static string _selected, _query = "", _package, _fingerprint;
        private static bool _initialized, _favoritesOnly, _busy;
        private static float _distance = 3f, _nextSpawn, _nextNetworkLabel;
        private static int _page, _scene = int.MinValue, _lifetime;

        public static void Initialize()
        {
            if (_initialized) return;
            _initialized = true;
            Settings.Load();
        }

        public static void Tick()
        {
            if (!_initialized) return;
            Guard(() =>
            {
                int scene = SceneManager.GetActiveScene().handle;
                if (_scene != scene) { _scene = scene; Close(); }
                if (!Application.isFocused) { Close(); return; }
                if (Input.GetKeyDown(ToggleKey))
                {
                    if (IsOpen) Close(); else Open();
                }
                else if (IsOpen && Input.GetKeyDown(KeyCode.Escape)) Close();
                if (!IsOpen) return;
                if (_root == null || _menuMarker == null) { Close(); return; }
                if (_fingerprint != FunContent.Fingerprint) RefreshCatalogue();
                if (Time.unscaledTime >= _nextNetworkLabel)
                {
                    _nextNetworkLabel = Time.unscaledTime + .25f;
                    _networkStatus.text = FunNetwork.IsServer ? "HOST" : FunNetwork.IsReady ? "CLIENT" : "ОЖИДАНИЕ СЕТИ";
                }
                _spawnButton.interactable = !_busy && _selected != null && FunNetwork.IsReady
                    && Time.unscaledTime >= _nextSpawn;
            });
        }

        public static void LateTick() { }

        public static void Open()
        {
            if (!_initialized) Initialize();
            if (IsOpen) return;
            try
            {
                if (_root == null || _menuMarker == null) { DestroyView(); Build(); }
                IsOpen = true; 
                _menuMarker.SetActive(true);
                AcquireInput();
                _root.SetActive(true);
                RefreshCatalogue();
                NotifyOpen(true);
            }
            catch (Exception e)
            {
                Close(); DestroyView();
                MelonLogger.Error("[SpawnUI] Cannot open panel: " + e);
            }
        }

        public static void Close()
        {
            if (!IsOpen) return;
            IsOpen = false;
            try
            {
                if (_search != null) _search.DeactivateInputField();
                if (_root != null) _root.SetActive(false);
            }
            finally
            {
                if (_menuMarker != null) _menuMarker.SetActive(false);
                ReleaseInput();
                NotifyOpen(false);
            }
        }

        public static void Shutdown()
        {
            try { Close(); }
            finally { DestroyView(); _initialized = false; }
        }

        internal static void Guard(Action action)
        {
            try { action(); }
            catch (Exception e)
            {
                MelonLogger.Error("[SpawnUI] " + e);
                if (_status != null) _status.text = "Ошибка: " + e.Message;
            }
        }

        private static void NotifyOpen(bool open)
        {
            if (OpenChanged == null) return;
            foreach (Action<bool> subscriber in OpenChanged.GetInvocationList())
                try { subscriber(open); }
                catch (Exception e) { MelonLogger.Warning("[SpawnUI] Input bridge: " + e.Message); }
        }

        private static void AcquireInput()
        {
            _previousEvents = EventSystem.current;
            foreach (var events in Object.FindObjectsOfType<EventSystem>())
            {
                if (events != null && events != _ownEvents && events.enabled)
                {
                    DisabledEvents.Add(events);
                    events.enabled = false;
                }
            }
            _eventRoot.SetActive(true);
            EventSystem.current = _ownEvents;
            var behaviours = GameplayBehavioursProvider?.Invoke();
            if (behaviours == null) return;
            foreach (var behaviour in behaviours)
            {
                if (behaviour == null || !behaviour.enabled || DisabledGameplay.Contains(behaviour)) continue;
                DisabledGameplay.Add(behaviour);
                behaviour.enabled = false;
            }
        }

        private static void ReleaseInput()
        {
            if (_eventRoot != null) _eventRoot.SetActive(false);
            foreach (var behaviour in DisabledGameplay)
                if (behaviour != null) behaviour.enabled = true;
            DisabledGameplay.Clear();
            foreach (var events in DisabledEvents)
                if (events != null) events.enabled = true;
            DisabledEvents.Clear();
            if (_previousEvents != null && _previousEvents.isActiveAndEnabled)
                EventSystem.current = _previousEvents;
            _previousEvents = null;
        }

        private static void Build()
        {
            _ui = new FunUiBuilder();
            var canvasRect = FunUiBuilder.Rect("FPE.SpawnConsole", null);
            _root = canvasRect.gameObject;
            _root.SetActive(false);
            Object.DontDestroyOnLoad(_root);
            var canvas = _root.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 30000;
            var scaler = _root.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1280, 800);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;
            _root.AddComponent<GraphicRaycaster>();
            var shade = FunUiBuilder.Rect("Shade", canvasRect);
            FunUiBuilder.Stretch(shade);
            FunUiBuilder.Background(shade, new Color(.01f, .02f, .04f, .78f));
            var panel = FunUiBuilder.Rect("Panel", shade);
            panel.anchorMin = panel.anchorMax = panel.pivot = new Vector2(.5f, .5f);
            panel.anchoredPosition = Vector2.zero;
            panel.sizeDelta = new Vector2(1100, 700);
            FunUiBuilder.Background(panel, new Color(.035f, .05f, .08f, 1));
            _ui.Label(panel, "Brand", "FUN+  /  КОНТЕНТ", 24, 15, 620, 35, 25);
            _ui.Label(panel, "Hint", "Выбери объект и создай его перед камерой", 24, 49, 680, 24, 15, FunUiBuilder.Muted);
            _networkStatus = _ui.Label(panel, "Network", "", 768, 22, 250, 24, 15, FunUiBuilder.Accent);
            _networkStatus.alignment = TextAnchor.MiddleRight;
            _ui.Button(panel, "X", 1036, 18, 40, 36, Close, out _);
            _search = _ui.Search(panel, 24, 88, 500, value => { _query = value; _page = 0; Refilter(); });
            _ui.Button(panel, "Пакет: все", 536, 88, 302, 42, CyclePackage, out _packageCaption);
            _ui.Button(panel, "Избранное: выкл", 850, 88, 226, 42,
                () => { _favoritesOnly = !_favoritesOnly; _page = 0; Refilter(); }, out _favoriteCaption);
            for (int i = 0; i < PageSize; i++)
            {
                var card = new Card();
                int index = i;
                var button = _ui.Button(panel, "", 24 + (i % 2) * 342, 148 + (i / 2) * 112,
                    330, 100, () => Select(Cards[index].AssetId), out _);
                card.Root = button.gameObject;
                card.Background = card.Root.GetComponent<Image>();
                card.Title = _ui.Label(card.Root.transform, "Title", "", 14, 10, 254, 30, 20);
                card.Id = _ui.Label(card.Root.transform, "Id", "", 14, 42, 302, 22, 13, FunUiBuilder.Muted);
                card.Kind = _ui.Label(card.Root.transform, "Kind", "", 14, 70, 302, 18, 13, FunUiBuilder.Accent);
                _ui.Button(card.Root.transform, "*", 282, 10, 36, 30,
                    () => ToggleFavorite(Cards[index].AssetId), out card.Star);
                Cards.Add(card);
            }
            _empty = _ui.Label(panel, "Empty", "Ничего не найдено", 24, 220, 672, 80, 23, FunUiBuilder.Muted);
            _empty.alignment = TextAnchor.MiddleCenter;
            var details = FunUiBuilder.Rect("Details", panel);
            FunUiBuilder.Place(details, 720, 148, 356, 436);
            FunUiBuilder.Background(details, FunUiBuilder.Surface);
            _ui.Label(details, "Selected", "ВЫБРАННЫЙ ОБЪЕКТ", 20, 14, 316, 25, 13, FunUiBuilder.Muted);
            _detailTitle = _ui.Label(details, "Title", "Выбери карточку", 20, 45, 316, 60, 25);
            _detailText = _ui.Label(details, "Description", "", 20, 115, 316, 128, 15, FunUiBuilder.Muted);
            _detailText.alignment = TextAnchor.UpperLeft;
            _favoriteButton = _ui.Button(details, "В избранное", 20, 262, 316, 36,
                () => ToggleFavorite(_selected), out _favoriteDetail);
            _ui.Button(details, "−", 20, 318, 42, 36, () => ChangeDistance(-.5f), out _);
            _distanceCaption = _ui.Label(details, "Distance", "Дистанция: 3 м", 68, 318, 220, 36, 17);
            _distanceCaption.alignment = TextAnchor.MiddleCenter;
            _ui.Button(details, "+", 294, 318, 42, 36, () => ChangeDistance(.5f), out _);
            _spawnButton = _ui.Button(details, "СОЗДАТЬ", 20, 374, 316, 42,
                () => { _ = SpawnSelectedAsync(); }, out _);
            _spawnButton.gameObject.GetComponent<Image>().color = new Color(.10f, .35f, .28f, 1);
            _previousPage = _ui.Button(panel, "Назад", 24, 606, 100, 34, () => { _page--; Render(); }, out _);
            _pageCaption = _ui.Label(panel, "Page", "", 130, 606, 460, 34, 16, FunUiBuilder.Muted);
            _pageCaption.alignment = TextAnchor.MiddleCenter;
            _nextPage = _ui.Button(panel, "Вперёд", 596, 606, 100, 34, () => { _page++; Render(); }, out _);
            _ui.Button(panel, "Обновить список", 720, 606, 356, 34, RefreshCatalogue, out _);
            _status = _ui.Label(panel, "Status", "", 24, 654, 1052, 26, 15, FunUiBuilder.Muted);
            _menuMarker = new GameObject("FPE.SpawnConsole.MenuMarker");
            _menuMarker.SetActive(false);
            _menuMarker.tag = "Menu";// cursor lock
            Object.DontDestroyOnLoad(_menuMarker);

            _eventRoot = new GameObject("FPE.SpawnConsole.EventSystem");
            _eventRoot.SetActive(false);
            Object.DontDestroyOnLoad(_eventRoot);
            _ownEvents = _eventRoot.AddComponent<EventSystem>();
            var module = _eventRoot.AddComponent<StandaloneInputModule>();
            module.forceModuleActive = true;
        }

        private static void RefreshCatalogue()
        {
            _fingerprint = FunContent.Fingerprint;
            _catalogue = FunContent.GetSpawnCatalogue().ToList();
            _packages = _catalogue.Select(e => e.PackageId).Distinct(StringComparer.Ordinal).OrderBy(p => p).ToList();
            if (_package != null && !_packages.Contains(_package)) _package = null;
            Refilter();
            SetStatus(FunContent.IsReady ? "F4 / Esc — закрыть. * — избранное. Спавн перед камерой."
                : FunContent.Ready.IsFaulted ? "Ошибка загрузки контента. Подробности в логе FunContent."
                : "Ожидание загрузки контента…");
        }

        private static void CyclePackage()
        {
            int next = _package == null ? 0 : _packages.IndexOf(_package) + 1;
            _package = next < _packages.Count ? _packages[next] : null;
            _page = 0; Refilter();
        }

        private static void Refilter()
        {
            string query = (_query ?? "").Trim();
            _filtered = _catalogue.Where(e => (_package == null || e.PackageId == _package)
                && (!_favoritesOnly || Settings.Favorites.Contains(e.Id))
                && (query.Length == 0 || e.Id.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0
                    || e.Title.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0)).ToList();
            if (!_filtered.Any(e => e.Id == _selected)) _selected = _filtered.FirstOrDefault()?.Id;
            Render();
        }

        private static void Select(string id) { if (id == null) return; _selected = id; Render(); }
        private static void ToggleFavorite(string id)
        {
            if (id == null) return;
            Settings.Toggle(id); Refilter();
        }
        private static void ChangeDistance(float delta)
        {
            _distance = Math.Clamp(_distance + delta, .5f, 20f);
            _distanceCaption.text = $"Дистанция: {_distance:0.#} м";
        }
        private static void Render()
        {
            int pages = Math.Max(1, (_filtered.Count + PageSize - 1) / PageSize);
            _page = Math.Clamp(_page, 0, pages - 1);
            _packageCaption.text = "Пакет: " + (_package ?? "все");
            _favoriteCaption.text = "Избранное: " + (_favoritesOnly ? "вкл" : "выкл");
            _pageCaption.text = $"{_page + 1} / {pages}    ·    Объектов: {_filtered.Count}";
            _previousPage.interactable = _page > 0;
            _nextPage.interactable = _page + 1 < pages;
            _empty.gameObject.SetActive(_filtered.Count == 0);
            for (int i = 0; i < Cards.Count; i++)
            {
                var card = Cards[i];
                int index = _page * PageSize + i;
                bool visible = index < _filtered.Count;
                card.Root.SetActive(visible);
                card.AssetId = visible ? _filtered[index].Id : null;
                if (!visible) continue;
                var entry = _filtered[index];
                card.Title.text = entry.Title;
                card.Id.text = entry.Id;
                card.Kind.text = entry.IsFactory ? "ФАБРИКА" : entry.ServerPhysics ? "БАНДЛ  /  ФИЗИКА" : "БАНДЛ";
                card.Star.color = Settings.Favorites.Contains(entry.Id) ? FunUiBuilder.Accent : FunUiBuilder.Muted;
                card.Background.color = entry.Id == _selected ? new Color(.10f, .24f, .23f, 1) : FunUiBuilder.Surface;
            }
            var selected = _filtered.FirstOrDefault(e => e.Id == _selected);
            _detailTitle.text = selected?.Title ?? "Нет объектов";
            _detailText.text = selected == null ? "Проверь поиск и фильтры.\nВ каталоге только сетевые GameObject."
                : $"ID: {selected.Id}\nПакет: {selected.PackageId}\nИсточник: {(selected.IsFactory ? "фабрика кода" : "AssetBundle")}\nФизика сервера: {(selected.ServerPhysics ? "да" : "нет")}";
            _favoriteButton.interactable = selected != null;
            _favoriteDetail.text = _selected != null && Settings.Favorites.Contains(_selected) ? "Убрать из избранного" : "В избранное";
        }

        private static async Task SpawnSelectedAsync()
        {
            if (_busy || Time.unscaledTime < _nextSpawn) return;
            int lifetime = _lifetime;
            _busy = true;
            _nextSpawn = Time.unscaledTime + .35f;
            try
            {
                if (!FunNetwork.IsReady) { SetStatus("Сеть или контент ещё не готовы."); return; }
                if (_selected == null) { SetStatus("Выбери объект."); return; }
                var camera = CameraProvider?.Invoke();
                if (camera == null) { SetStatus("Камера не найдена. Настрой CameraProvider."); return; }
                string id = _selected;
                Vector3 position = camera.transform.position + camera.transform.forward * _distance;
                if (FunNetwork.IsServer)
                {
                    SetStatus("Создание: " + id);
                    // UI scripts compile in the same FPE assembly, so its internal transport is available.
                    var identity = await FunNetwork.SpawnAsync(id, position, Quaternion.identity,
                        ownerClientId: FunTransport.LocalClientId);
                    if (lifetime != _lifetime) return;
                    SetStatus($"Создан: {id}  ·  сетевой ID {identity.Id}");
                }
                else
                {
                    bool sent = FunNetwork.RequestSpawn(id, position, Quaternion.identity);
                    SetStatus(sent ? "Запрос отправлен: " + id + ". Решение принимает сервер."
                        : "Запрос не отправлен: подключение ещё не готово.");
                    if (!sent) return;
                }
                if (CloseAfterSpawn) Close();
            }
            catch (Exception e)
            {
                MelonLogger.Error("[SpawnUI] Spawn failed: " + e);
                if (lifetime == _lifetime) SetStatus("Ошибка спавна: " + e.Message);
            }
            finally { if (lifetime == _lifetime) _busy = false; }
        }

        private static void SetStatus(string message) { if (_status != null) _status.text = message; }
        private static void DestroyView()
        {
            _lifetime++; _busy = false;
            // Destroy is deferred by Unity; clear the signal immediately.
            if (_menuMarker != null)
            {
                _menuMarker.SetActive(false);
                Object.Destroy(_menuMarker);
            }
            _menuMarker = null;
            _ui?.Dispose(); _ui = null;
            if (_root != null) Object.Destroy(_root);
            if (_eventRoot != null) Object.Destroy(_eventRoot);
            _root = null; _eventRoot = null; _ownEvents = null;
            _status = null; _search = null;
            Cards.Clear();
        }
    }
}
